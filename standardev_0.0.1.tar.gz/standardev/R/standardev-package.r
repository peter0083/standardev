#' standardev: a standard deviation calculator
#'
#' A simple standard deviation calculator to help user calculate standard deviation
#' of a given numeric/integer vector
#'
#' @name standardev
#' @docType package
NULL
